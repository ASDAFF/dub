-- phpMyAdmin SQL Dump
-- version 4.4.15.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 10, 2015 at 11:35 AM
-- Server version: 10.0.21-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dub`
--

-- --------------------------------------------------------

--
-- Table structure for table `antiBotCode`
--

CREATE TABLE IF NOT EXISTS `antiBotCode` (
  `ID` int(11) NOT NULL,
  `code` int(11) NOT NULL,
  `datePut` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antiBotCode`
--

INSERT INTO `antiBotCode` (`ID`, `code`, `datePut`) VALUES
(3, 371123, '2015-11-10 13:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `authorList`
--

CREATE TABLE IF NOT EXISTS `authorList` (
  `ID` int(11) NOT NULL,
  `name` text NOT NULL,
  `familyName` text NOT NULL,
  `bookCount` int(11) NOT NULL DEFAULT '0',
  `userID` int(11) NOT NULL DEFAULT '0',
  `datePut` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authorList`
--

INSERT INTO `authorList` (`ID`, `name`, `familyName`, `bookCount`, `userID`, `datePut`) VALUES
(1, 'А.В.', 'Тестовый', 1, 1, '2015-11-10 11:17:43');

-- --------------------------------------------------------

--
-- Table structure for table `booksAuthorList`
--

CREATE TABLE IF NOT EXISTS `booksAuthorList` (
  `ID` int(11) NOT NULL,
  `authorID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booksAuthorList`
--

INSERT INTO `booksAuthorList` (`ID`, `authorID`, `bookID`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `booksCategoryList`
--

CREATE TABLE IF NOT EXISTS `booksCategoryList` (
  `ID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booksCategoryList`
--

INSERT INTO `booksCategoryList` (`ID`, `categoryID`, `bookID`) VALUES
(1, 3, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `booksFileList`
--

CREATE TABLE IF NOT EXISTS `booksFileList` (
  `ID` int(11) NOT NULL,
  `storage` int(11) NOT NULL,
  `bookID` int(11) NOT NULL,
  `fileName` text NOT NULL,
  `fileSize` double NOT NULL,
  `fileFormat` enum('etc','djvu','pdf','txt') NOT NULL DEFAULT 'etc',
  `pages` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booksFileList`
--

INSERT INTO `booksFileList` (`ID`, `storage`, `bookID`, `fileName`, `fileSize`, `fileFormat`, `pages`) VALUES
(1, 4, 1, '1_kurs_obshhej_ximii_1990.djvu', 2949076, 'djvu', 462);

-- --------------------------------------------------------

--
-- Table structure for table `booksImageList`
--

CREATE TABLE IF NOT EXISTS `booksImageList` (
  `ID` int(11) NOT NULL,
  `imageName` text NOT NULL,
  `bookID` int(11) NOT NULL,
  `storage` int(11) NOT NULL,
  `orderID` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booksImageList`
--

INSERT INTO `booksImageList` (`ID`, `imageName`, `bookID`, `storage`, `orderID`) VALUES
(10, 'eab5fbafe1689262d427ed251ee9b94c.png', 1, 4, 4),
(9, '2203cab3e76b343bb2b86b5e400ba497.png', 1, 4, 3),
(8, 'b7400d1b27837b067e3aad7586f651ee.png', 1, 4, 2),
(7, 'ac23faa3a38b6b3161777f509a53c4d7.png', 1, 4, 1),
(6, '09f8314efb9eef9bdb90416f85cd7053.png', 1, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `booksList`
--

CREATE TABLE IF NOT EXISTS `booksList` (
  `ID` int(11) NOT NULL,
  `name` text NOT NULL,
  `smallDescr` text NOT NULL,
  `descr` text NOT NULL,
  `year` int(4) NOT NULL,
  `format` enum('djvu','pdf','txt','etc') NOT NULL DEFAULT 'etc',
  `rating` float NOT NULL DEFAULT '0',
  `ratingCount` int(11) NOT NULL DEFAULT '0',
  `downloadCount` int(11) NOT NULL DEFAULT '0',
  `readCount` int(11) NOT NULL DEFAULT '0',
  `readTextCount` int(11) NOT NULL DEFAULT '0',
  `free` enum('no','yes') NOT NULL DEFAULT 'yes',
  `userID` int(11) NOT NULL DEFAULT '0',
  `approved` enum('no','yes','finish','list') NOT NULL DEFAULT 'no',
  `datePut` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booksList`
--

INSERT INTO `booksList` (`ID`, `name`, `smallDescr`, `descr`, `year`, `format`, `rating`, `ratingCount`, `downloadCount`, `readCount`, `readTextCount`, `free`, `userID`, `approved`, `datePut`) VALUES
(1, 'Тестовая книга', 'Что то в описании аннотации', 'Что то в полном описании.', 2015, 'djvu', 0, 0, 0, 1, 0, 'yes', 1, 'yes', '2015-11-10 11:32:41');

-- --------------------------------------------------------

--
-- Table structure for table `booksMessages`
--

CREATE TABLE IF NOT EXISTS `booksMessages` (
  `ID` int(11) NOT NULL,
  `userName` text NOT NULL,
  `bookID` int(11) NOT NULL,
  `message` text NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `approved` enum('no','yes') NOT NULL DEFAULT 'no',
  `datePut` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `booksPrintList`
--

CREATE TABLE IF NOT EXISTS `booksPrintList` (
  `ID` int(11) NOT NULL,
  `printID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booksPrintList`
--

INSERT INTO `booksPrintList` (`ID`, `printID`, `bookID`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categoryList`
--

CREATE TABLE IF NOT EXISTS `categoryList` (
  `ID` int(11) NOT NULL,
  `name` text NOT NULL,
  `descr` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `parentID` int(11) NOT NULL,
  `bookCount` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categoryList`
--

INSERT INTO `categoryList` (`ID`, `name`, `descr`, `parentID`, `bookCount`) VALUES
(1, 'Тест 1', 'Что то в описании 1', 0, 0),
(2, 'Тест 2', 'Что то в описании 2', 0, 1),
(3, 'Саб Тест 1', 'Что то в описании 1 Саб', 1, 1),
(4, 'Саб Тест 2', 'Что то в описании 2 Саб', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `confirmEmail`
--

CREATE TABLE IF NOT EXISTS `confirmEmail` (
  `ID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `hash` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `datePut` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `logBook`
--

CREATE TABLE IF NOT EXISTS `logBook` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL DEFAULT '0',
  `code` int(11) NOT NULL,
  `datePut` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `printList`
--

CREATE TABLE IF NOT EXISTS `printList` (
  `ID` int(11) NOT NULL,
  `name` text NOT NULL,
  `city` text NOT NULL,
  `bookCount` int(11) NOT NULL DEFAULT '0',
  `userID` int(11) NOT NULL DEFAULT '0',
  `datePut` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `printList`
--

INSERT INTO `printList` (`ID`, `name`, `city`, `bookCount`, `userID`, `datePut`) VALUES
(1, 'Тестовое издательство', 'Измаил', 1, 1, '2015-11-10 11:18:01');

-- --------------------------------------------------------

--
-- Table structure for table `statAgentLog`
--

CREATE TABLE IF NOT EXISTS `statAgentLog` (
  `ID` int(11) NOT NULL,
  `userAgent` text COLLATE utf8_unicode_ci NOT NULL,
  `ip` text COLLATE utf8_unicode_ci NOT NULL,
  `datePut` date NOT NULL,
  `dateLast` datetime NOT NULL,
  `count` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `statAgentLog`
--

INSERT INTO `statAgentLog` (`ID`, `userAgent`, `ip`, `datePut`, `dateLast`, `count`) VALUES
(1, 'Mozilla/5.0 (X11; Linux x86_64; rv:41.0) Gecko/20100101 Firefox/41.0', '127.0.0.1', '2015-11-10', '2015-11-10 13:11:50', 13);

-- --------------------------------------------------------

--
-- Table structure for table `statQueryLog`
--

CREATE TABLE IF NOT EXISTS `statQueryLog` (
  `ID` int(11) NOT NULL,
  `agentID` int(11) NOT NULL,
  `query` text COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL DEFAULT '1',
  `datePut` date NOT NULL,
  `lastDate` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `statQueryLog`
--

INSERT INTO `statQueryLog` (`ID`, `agentID`, `query`, `count`, `datePut`, `lastDate`) VALUES
(1, 1, '127.0.0.1/dub/www/registration.php', 2, '2015-11-10', '2015-11-10 11:11:46'),
(2, 1, '127.0.0.1/dub/www/index.php', 4, '2015-11-10', '2015-11-10 11:33:21'),
(3, 1, '127.0.0.1/dub/www/showCategory.php?id=1', 2, '2015-11-10', '2015-11-10 11:47:23'),
(4, 1, '127.0.0.1/dub/www/showBook.php?id=1', 3, '2015-11-10', '2015-11-10 13:11:50'),
(5, 1, '127.0.0.1/dub/www/read.php?id=1', 1, '2015-11-10', '2015-11-10 11:46:33'),
(6, 1, '127.0.0.1/dub/www/showCategory.php?id=2', 1, '2015-11-10', '2015-11-10 11:47:26');

-- --------------------------------------------------------

--
-- Table structure for table `tiffImageList`
--

CREATE TABLE IF NOT EXISTS `tiffImageList` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL DEFAULT '0',
  `bookID` int(11) NOT NULL DEFAULT '0',
  `fileID` int(11) NOT NULL DEFAULT '0',
  `page` int(11) NOT NULL DEFAULT '0',
  `imageName` text COLLATE utf8_unicode_ci NOT NULL,
  `datePut` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tiket`
--

CREATE TABLE IF NOT EXISTS `tiket` (
  `ID` int(11) NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `userID` int(11) NOT NULL DEFAULT '0',
  `parentID` int(11) NOT NULL DEFAULT '0',
  `state` enum('open','close','answer') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `datePut` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL,
  `name` text NOT NULL,
  `passw` text NOT NULL,
  `email` text NOT NULL,
  `emailConfirm` enum('no','yes') NOT NULL DEFAULT 'no',
  `dateRegistration` datetime NOT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `ip` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state` enum('user','moderator','administrator') NOT NULL DEFAULT 'user',
  `ban` enum('no','yes') NOT NULL DEFAULT 'no',
  `amount` int(11) NOT NULL DEFAULT '0',
  `datePremium` datetime DEFAULT NULL,
  `freePremium` int(11) NOT NULL DEFAULT '1',
  `subscribe` enum('yes','no') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `name`, `passw`, `email`, `emailConfirm`, `dateRegistration`, `lastLogin`, `ip`, `state`, `ban`, `amount`, `datePremium`, `freePremium`, `subscribe`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@site.com', 'yes', '2015-11-10 11:11:46', '2015-11-10 11:31:39', '127.0.0.1', 'administrator', 'no', 100, NULL, 1, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `userImageRenderOptions`
--

CREATE TABLE IF NOT EXISTS `userImageRenderOptions` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `monochrome` enum('true','false') NOT NULL DEFAULT 'true',
  `transparent` enum('true','false') NOT NULL DEFAULT 'true',
  `colors` int(11) NOT NULL DEFAULT '16',
  `format` enum('png','gif','jpg') NOT NULL DEFAULT 'png',
  `resize` int(11) NOT NULL DEFAULT '794'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userLinks`
--

CREATE TABLE IF NOT EXISTS `userLinks` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL,
  `fileID` int(11) NOT NULL,
  `pageNum` int(11) NOT NULL,
  `datePut` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userOptions`
--

CREATE TABLE IF NOT EXISTS `userOptions` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userOptions`
--

INSERT INTO `userOptions` (`ID`, `userID`, `name`, `value`) VALUES
(54, 1, 'CurrentCountCommentsPost', '0'),
(55, 1, 'CurrentCountReadImage', '0'),
(56, 1, 'CurrentCountReadText', '0'),
(57, 1, 'CurrentCountGetFiles', '0'),
(58, 1, 'CurrentCountLogin', '0'),
(59, 1, 'CurrentCountGetFullTIFF', '0'),
(60, 1, 'CurrentCountSearch', '0'),
(61, 1, 'AuthorAdd', 'yes'),
(62, 1, 'AuthorEdit', 'yes'),
(63, 1, 'AuthorEditAll', 'yes'),
(64, 1, 'BookAdd', 'yes'),
(65, 1, 'BookEdit', 'yes'),
(66, 1, 'BookEditAll', 'yes'),
(67, 1, 'PrintAdd', 'yes'),
(68, 1, 'PrintEdit', 'yes'),
(69, 1, 'PrintEditAll', 'yes'),
(70, 1, 'CommentsPost', 'yes'),
(71, 1, 'ReadText', 'yes'),
(72, 1, 'GetFiles', 'yes'),
(73, 1, 'GetFullTIFF', 'yes'),
(74, 1, 'Search', 'yes'),
(75, 1, 'CommentsPostAntiBot', 'yes'),
(76, 1, 'GetFilesAntiBot', 'yes'),
(77, 1, 'CommentsShow', 'yes'),
(78, 1, 'BookShow', 'yes'),
(79, 1, 'BookRead', 'yes'),
(1, 0, 'nonAuthUserBookShow', 'yes'),
(2, 0, 'authUserBookShow', 'yes'),
(3, 0, 'nonAuthUserBookRead', 'yes'),
(4, 0, 'authUserBookRead', 'yes'),
(5, 0, 'authUserBookAdd', 'no'),
(6, 0, 'authUserBookEdit', 'no'),
(7, 0, 'nonAuthUserCommentsShow', 'yes'),
(8, 0, 'authUserCommentsShow', 'yes'),
(9, 0, 'nonAuthUserCommentsPost', 'yes'),
(10, 0, 'authUserCommentsPost', 'yes'),
(11, 0, 'nonAuthUserCommentsPostAntiBot', 'no'),
(12, 0, 'authUserCommentsPostAntiBot', 'yes'),
(13, 0, 'nonAuthUserGetFiles', 'yes'),
(14, 0, 'authUserGetFiles', 'yes'),
(15, 0, 'nonAuthUserGetFilesAntiBot', 'no'),
(16, 0, 'authUserGetFilesAntiBot', 'yes'),
(17, 0, 'nonAuthUserGetFullTIFF', 'yes'),
(18, 0, 'authUserGetFullTIFF', 'yes'),
(19, 0, 'authUserAuthorAdd', 'no'),
(20, 0, 'authUserAuthorEdit', 'no'),
(21, 0, 'authUserPrintAdd', 'no'),
(22, 0, 'authUserPrintEdit', 'no'),
(23, 0, 'authUserAuthorEditAll', 'no'),
(24, 0, 'authUserPrintEditAll', 'no'),
(25, 0, 'authUserBookEditAll', 'no'),
(26, 0, 'nonAuthUserSearch', 'yes'),
(27, 0, 'authUserSearch', 'yes'),
(28, 0, 'nonAuthUserReadText', 'yes'),
(29, 0, 'authUserReadText', 'yes'),
(30, 0, 'nonAuthUserLimitCommentsPost', '20'),
(31, 0, 'nonAuthUserAmountCommentsPost', '5'),
(32, 0, 'nonAuthUserCountCommentsPost', '10'),
(33, 0, 'nonAuthUserLimitReadImage', '200'),
(34, 0, 'nonAuthUserAmountReadImage', '5'),
(35, 0, 'nonAuthUserCountReadImage', '100'),
(36, 0, 'nonAuthUserLimitReadText', '200'),
(37, 0, 'nonAuthUserAmountReadText', '10'),
(38, 0, 'nonAuthUserCountReadText', '100'),
(39, 0, 'nonAuthUserLimitGetFiles', '20'),
(40, 0, 'nonAuthUserAmountGetFiles', '-10'),
(41, 0, 'nonAuthUserCountGetFiles', '20'),
(42, 0, 'nonAuthUserLimitLogin', '0'),
(43, 0, 'nonAuthUserAmountLogin', '100'),
(44, 0, 'nonAuthUserCountLogin', '1'),
(45, 0, 'nonAuthUserLimitGetFullTIFF', '100'),
(46, 0, 'nonAuthUserAmountGetFullTIFF', '0'),
(47, 0, 'nonAuthUserCountGetFullTIFF', '0'),
(48, 0, 'nonAuthUserLimitSearch', '20'),
(49, 0, 'nonAuthUserAmountSearch', '-2'),
(50, 0, 'nonAuthUserCountSearch', '0'),
(51, 0, 'nonAuthUserAmountReg', '100'),
(52, 0, 'nonAuthUserAmountBookAdd', '100');

-- --------------------------------------------------------

--
-- Table structure for table `userSession`
--

CREATE TABLE IF NOT EXISTS `userSession` (
  `ID` int(11) NOT NULL,
  `hash` text NOT NULL,
  `userID` int(11) NOT NULL,
  `userAgent` text NOT NULL,
  `lastPage` datetime NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userSession`
--

INSERT INTO `userSession` (`ID`, `hash`, `userID`, `userAgent`, `lastPage`, `created`) VALUES
(7, '2e1814d7fa791ae8f322661344771bf6', 1, 'Mozilla/5.0 (X11; Linux x86_64; rv:41.0) Gecko/20100101 Firefox/41.0', '2015-11-10 11:30:13', '2015-11-10 11:31:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `antiBotCode`
--
ALTER TABLE `antiBotCode`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `authorList`
--
ALTER TABLE `authorList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksAuthorList`
--
ALTER TABLE `booksAuthorList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksCategoryList`
--
ALTER TABLE `booksCategoryList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksFileList`
--
ALTER TABLE `booksFileList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksImageList`
--
ALTER TABLE `booksImageList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksList`
--
ALTER TABLE `booksList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksMessages`
--
ALTER TABLE `booksMessages`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booksPrintList`
--
ALTER TABLE `booksPrintList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `categoryList`
--
ALTER TABLE `categoryList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `confirmEmail`
--
ALTER TABLE `confirmEmail`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `logBook`
--
ALTER TABLE `logBook`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `printList`
--
ALTER TABLE `printList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `statAgentLog`
--
ALTER TABLE `statAgentLog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `statQueryLog`
--
ALTER TABLE `statQueryLog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tiffImageList`
--
ALTER TABLE `tiffImageList`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userImageRenderOptions`
--
ALTER TABLE `userImageRenderOptions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userLinks`
--
ALTER TABLE `userLinks`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userOptions`
--
ALTER TABLE `userOptions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userSession`
--
ALTER TABLE `userSession`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `antiBotCode`
--
ALTER TABLE `antiBotCode`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `authorList`
--
ALTER TABLE `authorList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `booksAuthorList`
--
ALTER TABLE `booksAuthorList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `booksCategoryList`
--
ALTER TABLE `booksCategoryList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `booksFileList`
--
ALTER TABLE `booksFileList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `booksImageList`
--
ALTER TABLE `booksImageList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `booksList`
--
ALTER TABLE `booksList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `booksMessages`
--
ALTER TABLE `booksMessages`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `booksPrintList`
--
ALTER TABLE `booksPrintList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `categoryList`
--
ALTER TABLE `categoryList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `confirmEmail`
--
ALTER TABLE `confirmEmail`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `logBook`
--
ALTER TABLE `logBook`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `printList`
--
ALTER TABLE `printList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `statAgentLog`
--
ALTER TABLE `statAgentLog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `statQueryLog`
--
ALTER TABLE `statQueryLog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tiffImageList`
--
ALTER TABLE `tiffImageList`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tiket`
--
ALTER TABLE `tiket`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `userImageRenderOptions`
--
ALTER TABLE `userImageRenderOptions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `userLinks`
--
ALTER TABLE `userLinks`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `userOptions`
--
ALTER TABLE `userOptions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `userSession`
--
ALTER TABLE `userSession`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
