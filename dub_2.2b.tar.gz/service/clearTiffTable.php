<?php

require_once "class.DB.php";

$objDB = new DB();

$objDB -> select("TRUNCATE TABLE tiffImageList;");

$objDB = 0;
?>